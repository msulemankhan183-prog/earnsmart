# EarnSmart v4 — AI courses + task platform prototype

## Features
- Mobile-first EarnSmart design.
- Four beginner courses: AI Basics, AI for Writing & Ideas, Graphic Design Starter, HTML & CSS Starter.
- Short lessons, knowledge-check quizzes, course filters, and localStorage progress.
- Account registration/login and task submission backend prototype.
- Admin submission review (local/testing only).
- Easypaisa withdrawal endpoint intentionally disabled.
- Courses are learning content only; no income or job guarantee.

## Run
Requirements: Node.js 20+ and a computer terminal.
1. Extract ZIP.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `ADMIN_TOKEN` to a random long secret (at least 32 characters for production).
5. Run `npm start`.
6. Open `http://localhost:3000`.

The admin review page uses the shared `ADMIN_TOKEN` as a prototype convenience only. Do not deploy publicly until replaced with role-based admin accounts, MFA, and audit logs.

## Course progress
Course progress is saved in the current browser using localStorage; it is not synced across devices and can be lost when browser data is cleared. To make course progress permanent across devices, add authenticated course-progress API routes and database tables.

## Real payments are NOT enabled
All tasks are unpaid practice tasks. The withdrawal endpoint always returns HTTP 503 and does not save or send payment details. Do not advertise real rewards or collect Easypaisa information until:
- you have a legitimate, funded task model and clear reward terms;
- user authentication, abuse controls, server-side reward ledger, payout review, transaction reconciliation and audit logs are implemented;
- Easypaisa confirms the relevant merchant/disbursement product, eligibility and API process;
- privacy notice, support process and applicable legal/account requirements are reviewed.
If the operator is under 18, involve a parent/guardian and verify provider and legal requirements before operating payments.

## Security status
Learning prototype, not production-ready. It still needs email verification, password reset, robust session management/revocation, per-user abuse controls, a proper admin role system, privacy/retention controls, security testing, and deployment hardening. Keep secrets out of frontend code and source control. Use HTTPS in production.
