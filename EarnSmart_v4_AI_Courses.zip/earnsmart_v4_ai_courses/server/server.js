require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");

const app = express();
const db = new Database(path.join(__dirname, "earnsmart.sqlite"));
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";
if (isProduction && (!process.env.ADMIN_TOKEN || process.env.ADMIN_TOKEN.length < 32 ||
    !process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("Production requires random ADMIN_TOKEN and SESSION_SECRET values of at least 32 chars.");
}
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "12kb" }));
app.use("/api/", rateLimit({ windowMs: 15*60*1000, limit: 100, standardHeaders: true, legacyHeaders: false }));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 salt TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 expires_at INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS submissions (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 task_id TEXT NOT NULL, response TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 reward_pkr INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS ledger (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 submission_id TEXT UNIQUE NOT NULL, amount_pkr INTEGER NOT NULL CHECK(amount_pkr > 0),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS payout_requests (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 amount_pkr INTEGER NOT NULL CHECK(amount_pkr > 0), status TEXT NOT NULL DEFAULT 'pending'
 CHECK(status IN ('pending','paid','rejected')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const TASKS = [
 { id:"design-tip", title:"Make a mini design checklist", description:"Write three things that make a social media graphic easy to read.", rewardPkr:0, label:"Practice · Unpaid", emoji:"🎨" },
 { id:"portfolio", title:"Plan your first portfolio", description:"List two beginner projects you could make to show your skills.", rewardPkr:0, label:"Practice · Unpaid", emoji:"💼" },
 { id:"html-basics", title:"Explain a website heading", description:"Explain in your own words what a heading does on a web page.", rewardPkr:0, label:"Practice · Unpaid", emoji:"🌐" },
 { id:"weekly-goal", title:"Set a learning goal", description:"Write one digital skill you want to practise this week.", rewardPkr:0, label:"Practice · Unpaid", emoji:"🎯" }
];
const taskById = new Map(TASKS.map(t => [t.id,t]));
const scryptAsync = (password, salt) => new Promise((resolve,reject) =>
 crypto.scrypt(password, salt, 64, (err,key) => err ? reject(err) : resolve(key.toString("hex"))));

function adminOnly(req,res,next) {
 const provided=req.get("x-admin-token")||"", expected=process.env.ADMIN_TOKEN||"";
 if(!expected || provided.length!==expected.length ||
    !crypto.timingSafeEqual(Buffer.from(provided),Buffer.from(expected))) return res.status(401).json({error:"Unauthorized"});
 next();
}
function requireUser(req,res,next) {
 const token=(req.get("authorization")||"").replace(/^Bearer\s+/i,"");
 if(!token) return res.status(401).json({error:"Sign in required"});
 const tokenHash=crypto.createHash("sha256").update(token).digest("hex");
 const session=db.prepare("SELECT s.user_id, u.email FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?").get(tokenHash,Date.now());
 if(!session) return res.status(401).json({error:"Session expired. Sign in again."});
 req.user={id:session.user_id,email:session.email}; next();
}
function balanceFor(userId) {
 return db.prepare("SELECT COALESCE(SUM(amount_pkr),0) AS total FROM ledger WHERE user_id=?").get(userId).total;
}
function newSession(userId) {
 const token=crypto.randomBytes(32).toString("base64url");
 db.prepare("INSERT INTO sessions (token_hash,user_id,expires_at) VALUES (?,?,?)")
 .run(crypto.createHash("sha256").update(token).digest("hex"),userId,Date.now()+7*24*60*60*1000);
 return token;
}

app.get("/api/health",(_req,res)=>res.json({ok:true,mode:"prototype",payoutsEnabled:false}));
app.get("/api/tasks",(_req,res)=>res.json({tasks:TASKS}));

app.post("/api/auth/register", async (req,res,next)=>{
 try {
  const email=typeof req.body?.email==="string"?req.body.email.trim().toLowerCase():"";
  const password=typeof req.body?.password==="string"?req.body.password:"";
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length>254) return res.status(400).json({error:"Enter a valid email"});
  if(password.length<10 || password.length>128) return res.status(400).json({error:"Password must be 10–128 characters"});
  if(db.prepare("SELECT id FROM users WHERE email=?").get(email)) return res.status(409).json({error:"An account with this email already exists"});
  const id=crypto.randomUUID(), salt=crypto.randomBytes(16).toString("hex");
  const hash=await scryptAsync(password,salt);
  db.prepare("INSERT INTO users(id,email,password_hash,salt) VALUES(?,?,?,?)").run(id,email,hash,salt);
  const token=newSession(id);
  res.status(201).json({user:{id,email},token});
 } catch(e){next(e);}
});
app.post("/api/auth/login",async(req,res,next)=>{
 try{
  const email=typeof req.body?.email==="string"?req.body.email.trim().toLowerCase():"";
  const password=typeof req.body?.password==="string"?req.body.password:"";
  const user=db.prepare("SELECT id,email,password_hash,salt FROM users WHERE email=?").get(email);
  if(!user || !await scryptAsync(password,user.salt).then(h=>crypto.timingSafeEqual(Buffer.from(h,"hex"),Buffer.from(user.password_hash,"hex"))).catch(()=>false))
   return res.status(401).json({error:"Invalid email or password"});
  res.json({user:{id:user.id,email:user.email},token:newSession(user.id)});
 }catch(e){next(e);}
});
app.get("/api/me",requireUser,(req,res)=>{
 const submitted=db.prepare("SELECT task_id,status FROM submissions WHERE user_id=?").all(req.user.id);
 res.json({user:req.user,balancePkr:balanceFor(req.user.id),submittedCount:submitted.length,
 pendingCount:submitted.filter(s=>s.status==="pending").length,submittedTaskIds:[...new Set(submitted.map(s=>s.task_id))]});
});
app.post("/api/auth/logout",requireUser,(req,res)=>{
 const token=(req.get("authorization")||"").replace(/^Bearer\s+/i,"");
 db.prepare("DELETE FROM sessions WHERE token_hash=?").run(crypto.createHash("sha256").update(token).digest("hex"));
 res.json({ok:true});
});
app.post("/api/submissions",requireUser,(req,res)=>{
 const {taskId,response}=req.body||{};
 if(typeof taskId!=="string"||!taskById.has(taskId)) return res.status(400).json({error:"Unknown task"});
 if(typeof response!=="string"||response.trim().length<8||response.length>1200) return res.status(400).json({error:"Response must be 8–1200 characters"});
 if(db.prepare("SELECT id FROM submissions WHERE user_id=? AND task_id=?").get(req.user.id,taskId))
   return res.status(409).json({error:"You have already submitted this task"});
 const id=crypto.randomUUID();
 db.prepare("INSERT INTO submissions(id,user_id,task_id,response) VALUES(?,?,?,?)").run(id,req.user.id,taskId,response.trim());
 res.status(201).json({id,status:"pending",message:"Practice task submitted. No payment is earned by this demo."});
});
app.get("/api/admin/submissions",adminOnly,(_req,res)=>{
 const rows=db.prepare(`SELECT s.id,s.task_id,s.response,s.status,s.reward_pkr,s.created_at,u.email,t.title AS task_title
 FROM submissions s JOIN users u ON u.id=s.user_id LEFT JOIN (SELECT id,title FROM json_each('[]')) t ON 1=0
 ORDER BY s.created_at DESC LIMIT 200`).all();
 // Attach task labels from the server-defined allowlist.
 res.json({submissions:rows.map(r=>({...r,task_title:taskById.get(r.task_id)?.title||r.task_id}))});
});
app.post("/api/admin/submissions/:id/decision",adminOnly,(req,res)=>{
 const {decision}=req.body||{};
 if(!["approved","rejected"].includes(decision)) return res.status(400).json({error:"Decision must be approved or rejected"});
 const row=db.prepare("SELECT id,task_id,status FROM submissions WHERE id=?").get(req.params.id);
 if(!row) return res.status(404).json({error:"Submission not found"});
 if(row.status!=="pending") return res.status(409).json({error:"Submission already reviewed"});
 // All built-in tasks are unpaid; approving one never creates money.
 db.prepare("UPDATE submissions SET status=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?").run(decision,row.id);
 res.json({id:row.id,status:decision,rewardPkr:0,message:"Practice tasks do not pay real money."});
});
app.post("/api/payout-requests",requireUser,(_req,res)=>{
 // Intentionally disabled until an approved balance ledger and official payment provider workflow exist.
 res.status(503).json({error:"Easypaisa payouts are not connected. No payment details were saved or sent."});
});
app.use(express.static(path.join(__dirname,"..","public")));
app.get("/",(_req,res)=>res.sendFile(path.join(__dirname,"..","public","index.html")));
app.use((err,_req,res,_next)=>{console.error("Request failed:",err.message);res.status(500).json({error:"Internal server error"});});
app.listen(PORT,()=>console.log(`EarnSmart v3 at http://localhost:${PORT} — demo only; payouts disabled.`));
