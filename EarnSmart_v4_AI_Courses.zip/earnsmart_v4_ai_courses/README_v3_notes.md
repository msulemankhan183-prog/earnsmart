# EarnSmart v3 — account + task-review prototype

## Included
- Mobile-first frontend.
- Email/password registration and login (passwords hashed with Node scrypt).
- Server-side sessions stored as hashes; session token held in browser sessionStorage.
- SQLite persistence for users and submissions.
- Task submissions and local admin approve/reject review.
- Basic request rate limit, Helmet security headers, JSON size limit, input validation.
- Easypaisa withdrawal endpoint is intentionally disabled; no payout or real reward is issued.

## Run locally
Requirements: Node.js 20+ and a computer terminal.
1. Extract ZIP.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set a long random `ADMIN_TOKEN` (at least 32 chars for production) and `SESSION_SECRET` (reserved for a future hardened auth design; keep secret).
5. Run `npm start`.
6. Open `http://localhost:3000`.

Admin review: enter the value of `ADMIN_TOKEN` in the Admin review section. For local testing only. Do not expose this admin-token design to a public production site; use proper admin accounts, MFA and audit logs.

## Limitations — read before launch
This is a learning prototype, not production-ready:
- No email verification, password reset, MFA, CSRF model, formal privacy/retention workflow, or user moderation.
- Admin access uses one shared token and must be replaced by role-based admin accounts.
- No paid tasks are configured: all rewards are zero.
- Withdrawal endpoint always returns 503; it does not collect or transfer funds.
- Session secret is reserved but this prototype currently uses random bearer tokens with hashed server-side storage. Add token rotation, session revocation, expiry cleanup, secure device management and further review before public use.
- No payment provider credentials, webhooks, Easypaisa API or real payouts are implemented.
- Do not deploy this as a public earning platform until a qualified developer reviews and hardens it.

## Real payment checklist
1. Contact Easypaisa official merchant/business support and confirm the exact product, eligibility and whether your intended disbursement workflow is supported.
2. Establish a real task supply and funding model. Do not promise rewards unless funds are available and terms are clear.
3. Add server-side approved task reward ledger with append-only entries, unique transaction IDs, idempotency and reconciliation.
4. Build authenticated payout requests with available-balance locking and duplicate prevention.
5. Verify provider callbacks cryptographically and reconcile transfers before marking requests paid.
6. Publish clear terms, privacy notice, support/refund process, fraud policy and retention/deletion rules.
7. Test security, backups, rate limits, abuse prevention, logs and admin controls.
8. If the operator is under 18, involve a parent/guardian and verify legal, merchant and account requirements before operating payments.
