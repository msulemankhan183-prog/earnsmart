const $ = (id) => document.getElementById(id);
let tasks = [];
let currentUser = null;
let activeTask = null;
let activeCourse = null;
let sessionToken = sessionStorage.getItem("earnsmart_session") || "";
const submitted = new Set();

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message; toast.style.display = "block";
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.style.display = "none", 3000);
}
async function api(url, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (sessionToken) headers.Authorization = `Bearer ${sessionToken}`;
  const response = await fetch(url, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function renderTasks() {
  $("task-count").textContent = `${tasks.length} tasks`;
  $("task-list").innerHTML = tasks.map(task => `
    <article class="task-card"><div class="task-top">
      <div class="task-emoji" aria-hidden="true">${escapeHtml(task.emoji || "🧩")}</div>
      <div class="task-main"><h3>${escapeHtml(task.title)}</h3><p>${escapeHtml(task.description)}</p></div>
      <div class="reward">${task.rewardPkr > 0 ? `Rs ${task.rewardPkr}` : "Practice"}</div>
    </div><div class="task-bottom"><span class="task-type">${escapeHtml(task.label || "Task")}</span>
    <button class="primary-button" data-task="${escapeHtml(task.id)}" ${submitted.has(task.id) ? "disabled" : ""}>${submitted.has(task.id) ? "Submitted ✓" : "Open task"}</button></div></article>`).join("");
  $("task-list").querySelectorAll("[data-task]").forEach(b => b.addEventListener("click", () => openTask(b.dataset.task)));
}
const COURSES = [
 {id:"ai-basics",category:"AI",icon:"🤖",title:"AI Basics for Beginners",level:"Beginner",duration:"4 short lessons",description:"Learn what AI is, where it helps, and why human checking matters.",lessons:[
  {title:"1. What is AI?",body:"Artificial intelligence (AI) describes computer systems that perform tasks such as recognizing patterns, generating text, or making predictions. AI can be useful, but it can also make mistakes.",points:["AI tools find patterns from examples and data.","AI output should be checked before you rely on it.","Do not enter private information into public AI tools."],q:"Which statement about AI is most accurate?",options:["AI is always correct","AI can help but may make mistakes","AI replaces the need to think"],correct:1},
  {title:"2. Writing better prompts",body:"A prompt is the instruction you give an AI tool. Clear prompts explain the goal, audience, format, and any important limits.",points:["Say what you need.","Give context that is safe to share.","Ask for a format, such as a checklist or short explanation."],q:"Which prompt is clearer?",options:["Do something","Explain photosynthesis in 5 simple bullet points for a beginner"],correct:1},
  {title:"3. Check AI answers",body:"AI can produce inaccurate details. Compare important claims with reliable sources and ask for explanations when something is unclear.",points:["Check facts, names, dates, and calculations.","Do not present generated work as your own if rules forbid it.","Use AI to learn, brainstorm, and revise responsibly."],q:"What should you do with an important AI-generated fact?",options:["Trust it automatically","Check it against reliable sources","Share it without reading"],correct:1},
  {title:"4. Privacy and responsible use",body:"Protect yourself and others when using AI. Avoid sharing personal data, passwords, private photos, or information you do not have permission to use.",points:["Keep passwords and verification codes private.","Get permission before uploading someone else's content.","Follow school, workplace, and platform rules."],q:"What should never be shared with a public AI chatbot?",options:["A made-up example","Your password or one-time code","A general question about learning"],correct:1}
 ]},
 {id:"ai-content",category:"AI",icon:"✍️",title:"AI for Writing & Ideas",level:"Beginner",duration:"3 short lessons",description:"Use AI to brainstorm, outline, and improve writing without losing your own voice.",lessons:[
  {title:"1. Brainstorm ideas",body:"AI can help generate options when you are stuck. Choose the ideas that fit your purpose and check that they are appropriate.",points:["Ask for several options.","Pick and adapt ideas yourself.","Avoid copying someone else's work."],q:"What is a good use of AI brainstorming?",options:["Generate ideas then choose thoughtfully","Submit everything without reading","Copy a private person's data"],correct:0},
  {title:"2. Make an outline",body:"An outline organizes your main point, supporting points, and conclusion. Ask for structure, then write and revise in your own words.",points:["Start with a clear purpose.","Organize points logically.","Review the result for accuracy and tone."],q:"What helps make a draft clearer?",options:["No structure","A clear outline and review","More complicated words every time"],correct:1},
  {title:"3. Edit responsibly",body:"AI can suggest grammar and clarity improvements. Keep your meaning, verify facts, and follow any rules about AI assistance.",points:["Review every suggested change.","Keep your own perspective.","Disclose AI help when required."],q:"After AI edits your draft, you should…",options:["Review the edits and confirm they preserve your meaning","Assume every edit is perfect","Delete your own ideas"],correct:0}
 ]},
 {id:"design-start",category:"Design",icon:"🎨",title:"Graphic Design Starter",level:"Beginner",duration:"3 short lessons",description:"Learn layout, contrast, and readable designs for thumbnails and posts.",lessons:[
  {title:"1. Visual hierarchy",body:"Visual hierarchy helps people notice the most important information first. Use size, placement, and spacing to guide attention.",points:["Give the main headline priority.","Keep enough empty space.","Use consistent alignment."],q:"What should usually stand out first in a poster?",options:["The main message","Tiny decorative text","Every element equally"],correct:0},
  {title:"2. Contrast and readability",body:"Contrast makes text and important elements easier to see. Check readability on a small phone screen.",points:["Use readable text/background contrast.","Avoid too many fonts.","Do not place text over a busy image without a clear background."],q:"How can you improve small-screen readability?",options:["Use low contrast","Use clear contrast and readable type","Shrink all text"],correct:1},
  {title:"3. Design practice",body:"A useful beginner project is a simple event poster or video thumbnail. Make one clear focal point and check spacing.",points:["Choose one goal for the design.","Use licensed or self-created assets.","Ask for feedback and revise."],q:"What is a sensible first design project?",options:["A simple poster with one clear message","A page with every effect at once","Copy a paid design exactly"],correct:0}
 ]},
 {id:"web-starter",category:"Web",icon:"🌐",title:"HTML & CSS Starter",level:"Beginner",duration:"3 short lessons",description:"Understand web page structure, styling, and responsive layouts.",lessons:[
  {title:"1. HTML structure",body:"HTML describes the content and structure of a page. Headings, paragraphs, links, and buttons have different purposes.",points:["Use headings in a logical order.","Use links for navigation.","Label form inputs clearly."],q:"What is HTML mainly used for?",options:["Structuring web content","Charging a phone","Editing audio only"],correct:0},
  {title:"2. CSS styling",body:"CSS controls presentation, including colors, spacing, fonts, and layouts. Reusable rules make pages easier to maintain.",points:["Use consistent spacing.","Check text contrast.","Keep styles organized."],q:"What does CSS control?",options:["Page appearance and layout","The user's bank account","Internet speed"],correct:0},
  {title:"3. Responsive design",body:"Responsive design adapts a page to different screen sizes. Start with a narrow layout, then enhance it for wider screens.",points:["Use the viewport meta tag.","Avoid fixed widths that overflow.","Test on a real phone when possible."],q:"What is responsive design?",options:["A page that adapts to screen sizes","A page that only works on one laptop","A payment method"],correct:0}
 ]}
];
let courseFilter = "all";
let courseProgress = {};
try { courseProgress = JSON.parse(localStorage.getItem("earnsmart_course_progress") || "{}"); } catch { courseProgress = {}; }
function saveCourseProgress(){ try { localStorage.setItem("earnsmart_course_progress", JSON.stringify(courseProgress)); } catch {} }
function coursePercent(course){ const done = new Set(courseProgress[course.id] || []); return Math.round(done.size / course.lessons.length * 100); }
function renderCourses(){
 const visible = COURSES.filter(c => courseFilter === "all" || c.category === courseFilter);
 $("course-list").innerHTML = visible.map(c => {
   const percent = coursePercent(c);
   return `<article class="course-card"><div class="course-card-top"><div class="course-icon">${c.icon}</div><div style="flex:1"><h3>${escapeHtml(c.title)}</h3><p>${escapeHtml(c.description)}</p></div></div><div class="course-meta"><span>${escapeHtml(c.category)}</span><span>${escapeHtml(c.level)}</span><span>${escapeHtml(c.duration)}</span></div><div class="course-progress"><span style="width:${percent}%"></span></div><div class="course-progress-text"><span>${percent === 100 ? "Completed" : "Your progress"}</span><span>${percent}%</span></div><button class="primary-button" data-course="${c.id}">${percent === 100 ? "Review course" : "Start learning"}</button></article>`;
 }).join("");
 $("course-list").querySelectorAll("[data-course]").forEach(b => b.addEventListener("click", () => openCourse(b.dataset.course)));
}
function openCourse(id){
 activeCourse = COURSES.find(c => c.id === id);
 if(!activeCourse) return;
 const completed = new Set(courseProgress[id] || []);
 const next = activeCourse.lessons.findIndex((l,i) => !completed.has(i));
 const lessonIndex = next < 0 ? 0 : next;
 showLesson(lessonIndex);
}
function showLesson(index){
 const lesson = activeCourse.lessons[index];
 if(!lesson) return;
 let panel = $("lesson-panel");
 if(!panel){ panel=document.createElement("section"); panel.id="lesson-panel"; panel.className="lesson-panel"; $("course-list").after(panel); }
 panel.innerHTML = `<div class="section-title"><div><p class="eyebrow">${escapeHtml(activeCourse.title)}</p><h2>${escapeHtml(lesson.title)}</h2></div><button class="text-button" id="close-lesson">Close ×</button></div><p>${escapeHtml(lesson.body)}</p><ul>${lesson.points.map(p=>`<li>${escapeHtml(p)}</li>`).join("")}</ul><p class="quiz-question">${escapeHtml(lesson.q)}</p><div class="quiz-options">${lesson.options.map((o,i)=>`<button class="quiz-option" data-option="${i}">${escapeHtml(o)}</button>`).join("")}</div><p class="fine-print" id="quiz-feedback">Choose an answer to check your understanding.</p><button class="primary-button full" id="next-lesson" disabled>${index === activeCourse.lessons.length-1 ? "Finish course" : "Next lesson"}</button>`;
 panel.scrollIntoView({behavior:"smooth",block:"start"});
 $("close-lesson").addEventListener("click",()=>panel.remove());
 let answered=false;
 panel.querySelectorAll("[data-option]").forEach(button=>button.addEventListener("click",()=>{
   if(answered)return; answered=true;
   const choice=Number(button.dataset.option), correct=choice===lesson.correct;
   button.classList.add(correct?"correct":"wrong");
   $("quiz-feedback").textContent=correct?"Correct — lesson completed!":"Not quite. Review the lesson and try again in the next visit.";
   if(correct){
     const done=new Set(courseProgress[activeCourse.id]||[]);done.add(index);courseProgress[activeCourse.id]=[...done];saveCourseProgress();
     panel.querySelectorAll("[data-option]").forEach(b=>b.disabled=true);
     $("next-lesson").disabled=false;
   } else { answered=false; button.disabled=true; }
 }));
 $("next-lesson").addEventListener("click",()=>{
   if(index<activeCourse.lessons.length-1) showLesson(index+1);
   else {renderCourses();panel.remove();showToast("Course progress saved on this device.");}
 });
}
async function loadTasks() {
  try { const data = await api("/api/tasks"); tasks = data.tasks; renderTasks(); }
  catch (e) { $("task-list").innerHTML = `<p class="section-desc">Could not load tasks. Start the backend and refresh this page.</p>`; showToast(e.message); }
}
function openTask(id) {
  activeTask = tasks.find(t => t.id === id);
  if (!activeTask) return;
  $("task-id").value = activeTask.id;
  $("dialog-title").textContent = activeTask.title;
  $("dialog-description").textContent = activeTask.description;
  $("answer").value = "";
  $("task-dialog").showModal();
}
async function submitTask(event) {
  event.preventDefault();
  if (!currentUser) { showToast("Please create an account or sign in first."); $("account").scrollIntoView({behavior:"smooth"}); return; }
  const response = $("answer").value.trim();
  if (response.length < 8) { showToast("Please write at least 8 characters."); return; }
  try {
    await api("/api/submissions", { method:"POST", body: JSON.stringify({ taskId: activeTask.id, response }) });
    submitted.add(activeTask.id);
    $("submitted").textContent = String(submitted.size);
    $("status-note").textContent = "Pending review";
    renderTasks(); $("task-dialog").close();
    showToast("Submitted for review. Demo tasks do not pay money.");
  } catch (e) { showToast(e.message); }
}
function setAccount(user, token) {
  currentUser = user;
  sessionToken = token || "";
  if (sessionToken) sessionStorage.setItem("earnsmart_session", sessionToken);
  else sessionStorage.removeItem("earnsmart_session");
  $("account-status").textContent = user ? `Signed in as ${user.email}` : "Not signed in.";
  $("logout-btn").hidden = !user;
  $("register-btn").hidden = !!user;
  $("login-btn").hidden = !!user;
}
async function auth(mode) {
  const email = $("email").value.trim().toLowerCase();
  const password = $("password").value;
  if (!email || password.length < 10) { showToast("Enter a valid email and password of at least 10 characters."); return; }
  try {
    const data = await api(`/api/auth/${mode}`, { method:"POST", body:JSON.stringify({email,password}) });
    setAccount(data.user, data.token);
    await loadMe();
    showToast(mode === "register" ? "Account created." : "Signed in.");
  } catch(e) { showToast(e.message); }
}
async function loadMe() {
  if (!sessionToken) return;
  try {
    const data = await api("/api/me");
    currentUser = data.user;
    $("balance").textContent = `Rs ${data.balancePkr}`;
    $("submitted").textContent = String(data.submittedCount);
    $("status-note").textContent = `${data.pendingCount} pending`;
    setAccount(data.user, sessionToken);
    (data.submittedTaskIds || []).forEach(id => submitted.add(id));
    renderTasks();
  } catch { setAccount(null, ""); }
}
async function loadReview() {
  const token = $("admin-token").value.trim();
  if (!token) { showToast("Enter the server admin token."); return; }
  try {
    const data = await api("/api/admin/submissions", { headers: { "x-admin-token": token } });
    $("review-list").innerHTML = data.submissions.length ? data.submissions.map(s => `
      <article class="review-item"><strong>${escapeHtml(s.task_title)} · ${escapeHtml(s.status)}</strong>
      <p>${escapeHtml(s.response)}</p><small>${escapeHtml(s.email)} · ${escapeHtml(s.created_at)}</small>
      ${s.status === "pending" ? `<div class="review-buttons"><button class="small-button approve" data-decision="approved" data-id="${escapeHtml(s.id)}">Approve</button><button class="small-button" data-decision="rejected" data-id="${escapeHtml(s.id)}">Reject</button></div>` : ""}</article>`).join("") : "<p class='fine-print'>No submissions yet.</p>";
    $("review-list").querySelectorAll("[data-decision]").forEach(b => b.addEventListener("click", () => decideReview(b.dataset.id, b.dataset.decision, token)));
  } catch(e) { showToast(e.message); }
}
async function decideReview(id, decision, token) {
  try {
    await api(`/api/admin/submissions/${encodeURIComponent(id)}/decision`, { method:"POST", headers:{"x-admin-token":token}, body:JSON.stringify({decision}) });
    showToast(`Submission ${decision}.`); await loadReview(); await loadMe();
  } catch(e) { showToast(e.message); }
}
$("submission-form").addEventListener("submit", submitTask);
$("register-btn").addEventListener("click", () => auth("register"));
$("login-btn").addEventListener("click", () => auth("login"));
$("logout-btn").addEventListener("click", () => { setAccount(null, ""); $("balance").textContent = "Rs 0"; showToast("Signed out."); });
$("load-review-btn").addEventListener("click", loadReview);
$("withdraw-btn").addEventListener("click", async () => {
  if (!currentUser) { showToast("Sign in first."); return; }
  const amount = Number($("amount").value);
  const wallet = $("wallet").value.trim();
  if (!/^03\d{9}$/.test(wallet) || !Number.isInteger(amount) || amount < 1) { showToast("Enter a valid Pakistani mobile number and whole PKR amount."); return; }
  try {
    await api("/api/payout-requests", { method:"POST", body:JSON.stringify({ amountPkr:amount, easypaisaNumber:wallet }) });
  } catch(e) { showToast(e.message); }
  $("wallet").value = ""; $("amount").value = "";
});
document.querySelectorAll("[data-filter]").forEach(button => button.addEventListener("click", () => {
  courseFilter = button.dataset.filter;
  document.querySelectorAll("[data-filter]").forEach(b => b.classList.toggle("active", b === button));
  renderCourses();
}));
$("year").textContent = new Date().getFullYear();
renderCourses();
loadTasks().then(loadMe);
